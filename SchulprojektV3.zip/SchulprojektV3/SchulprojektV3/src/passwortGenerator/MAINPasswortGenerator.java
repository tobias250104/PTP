package passwortGenerator;

public class MAINPasswortGenerator 
{

// ------------------------ I N F O R M A T I O N ------------------------\
//	-> Alle Dateipfade in GUIPasswortGenerator m�ssen angepasst werden!
// -----------------------------------------------------------------------\
	
}
